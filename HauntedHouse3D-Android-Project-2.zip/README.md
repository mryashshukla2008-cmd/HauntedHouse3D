# Haunted House 3D V143 — Android build project

This project packages the supplied `haunted_house_v143.cpp` source with SDL2 for Android.
The GitHub Actions workflow downloads SDL2 2.30.10, copies SDL's Android Java bridge,
and builds a debug APK for `arm64-v8a` and `armeabi-v7a`.

## Important
- This is a first Android packaging build, not a guarantee of runtime correctness.
- The original C++ gameplay source is included unchanged.
- Test the generated APK on the target phone before distributing it.
- Do not upload signing keys or passwords to this repository.
