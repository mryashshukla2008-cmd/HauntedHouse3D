cmake_minimum_required(VERSION 3.22.1)
project(HauntedHouse3D LANGUAGES C CXX)

set(SDL2_SRC_DIR "${CMAKE_CURRENT_SOURCE_DIR}/SDL2")
if(NOT EXISTS "${SDL2_SRC_DIR}/CMakeLists.txt")
    message(FATAL_ERROR "SDL2 source is missing. The GitHub Actions workflow must download SDL2 before building.")
endif()

set(SDL_SHARED ON CACHE BOOL "" FORCE)
set(SDL_STATIC OFF CACHE BOOL "" FORCE)
set(SDL_TEST OFF CACHE BOOL "" FORCE)
set(SDL_VULKAN OFF CACHE BOOL "" FORCE)
set(SDL_OPENGLES ON CACHE BOOL "" FORCE)

add_subdirectory("${SDL2_SRC_DIR}" "${CMAKE_CURRENT_BINARY_DIR}/SDL2_build")

# The existing game includes headers as <SDL2/SDL.h>.
set(COMPAT_INCLUDE "${CMAKE_CURRENT_BINARY_DIR}/compat_include")
file(MAKE_DIRECTORY "${COMPAT_INCLUDE}")
file(CREATE_LINK "${SDL2_SRC_DIR}/include" "${COMPAT_INCLUDE}/SDL2" SYMBOLIC)

add_library(main SHARED
    "${SDL2_SRC_DIR}/src/main/android/SDL_android_main.c"
    "${CMAKE_CURRENT_SOURCE_DIR}/haunted_house_v143.cpp"
)

target_include_directories(main PRIVATE
    "${COMPAT_INCLUDE}"
    "${SDL2_SRC_DIR}/include"
)

target_compile_features(main PRIVATE cxx_std_17)
target_link_libraries(main PRIVATE SDL2 GLESv2 EGL android log m)
